# Credit Risk Prediction — Applied Machine Learning

Academic machine-learning notebook from the Applied Machine Learning course at Sheffield Hallam University, prepared for a portfolio by **Ifeanyi Jordan Nnamani**.

## Overview
The notebook explores predicting the binary `loan_status` target from credit-risk attributes, with data inspection, preprocessing, visualisation, modelling and discussion of deployment and fairness.

## Methods contained in the submitted notebook
- Exploratory data analysis, feature distributions, outlier and missing-data checks, and correlation heat maps.
- Logistic Regression, Random Forest and Gradient Boosting comparisons with precision, recall and ROC-AUC.
- Model selection and local explanation approaches (SHAP where available).
- Fairness analysis across age bands, a proposed deployment architecture and drift simulation.
- Stratified cross-validation and optional TabNet exploration.

The analysis and conclusions are those recorded in the original submitted notebook. **Results have not been independently rerun or verified for this portfolio package.**

## Files
- `credit_risk_analysis.ipynb` — original uploaded academic notebook, renamed for clarity.
- `requirements.txt` — core Python packages, plus optional ML packages.
- `.gitignore` — common Python/Jupyter exclusions.

## Dataset required
The notebook expects `credit_risk_dataset.csv` in its working folder. **That dataset is not included here.** Obtain the original dataset used for the coursework, confirm that it can lawfully be redistributed, and place it alongside the notebook before running.

A later section also attempts to read `UCI_Credit_Card.csv`; that dataset is likewise not included. Some optional advanced analysis requires `pytorch-tabnet` and/or `shap`.

## Run locally
1. Install Python and Jupyter.
2. Create and activate a virtual environment.
3. Run `pip install -r requirements.txt`.
4. Add the permitted coursework data files to the project directory.
5. Start `jupyter notebook` and open `credit_risk_analysis.ipynb`.
6. Run cells sequentially and review outputs. Optional sections may require additional packages or datasets.

## Portfolio next steps
- Attach a dataset source and licence.
- Rerun the notebook end-to-end, ensuring reproducible preprocessing and model evaluation.
- Report actual test-set metrics in this README only after validating them.
- Check and document data leakage and fairness limitations before making real-world claims.

## Notes
This is an educational exploration, **not a validated lending decision system**. The work should not be used to make credit decisions about people.
